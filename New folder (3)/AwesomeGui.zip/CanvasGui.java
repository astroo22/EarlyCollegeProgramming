
import java.awt.*;
import javax.swing.*;

public class CanvasGui extends JPanel
{
	public double x,y; // top left corner of ball
	public double w,h; // width and height of ball
	public double vx,vy;

	public CanvasGui()
	{
		x = 0;
		y = 0;
		w = 30;
		h = 30;
		vx = 3.0;
		vy = 0.0;
	}

	public void update()
	{
		double width = getWidth();
		double height = getHeight();

		//if (!((y+h) > height))
			vy += 1.0;

		x += vx;
		y += vy;

		if (x < 0)
		{
			vx = Math.abs(vx);
		}
		if ((x+w) > width)
		{
			vx = -Math.abs(vx);
		}

		if (y < 0)
		{
			vy = Math.abs(vy);
		}
		if ((y+h) > height)
		{
			vy = -Math.abs(vy);
			y = height - h;
		}
	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		setForeground(Color.RED);
		g.fillOval((int)x, (int)y, (int)w, (int)h);
	}
}